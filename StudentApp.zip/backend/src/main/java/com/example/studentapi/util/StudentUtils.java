
package com.example.studentapi.util;

import com.example.studentapi.model.Student;
import java.util.List;

public class StudentUtils {
    public static double calculateAverageGrade(List<Integer> grades) {
        return grades.stream().mapToInt(Integer::intValue).average().orElse(0.0);
    }

    public static double calculateSuccessScore(Student student) {
        double avgGrade = calculateAverageGrade(student.getGrades());
        return (0.5 * avgGrade) + (0.3 * student.getAttendance()) + (0.2 * student.getAssignments());
    }

    public static String categorize(double score) {
        if (score >= 85) return "Excellent";
        else if (score >= 65) return "Average";
        else return "Needs Improvement";
    }

    public static void enrichStudent(Student student) {
        double avgGrade = calculateAverageGrade(student.getGrades());
        student.setAvgGrade(avgGrade);
        double score = calculateSuccessScore(student);
        student.setSuccessScore(score);
        student.setCategory(categorize(score));
    }
}
