
package com.example.studentapi.service;

import com.example.studentapi.model.Student;
import com.example.studentapi.repository.StudentRepository;
import com.example.studentapi.util.StudentUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student getStudentById(Long id) {
        return studentRepository.findById(id).orElseThrow(() -> new RuntimeException("Student not found"));
    }

    public Map<String, Object> getStatistics() {
        List<Student> students = studentRepository.findAll();
        double avgGrade = students.stream().mapToDouble(Student::getAvgGrade).average().orElse(0.0);
        Map<String, Long> categoryDistribution = students.stream()
                .collect(Collectors.groupingBy(Student::getCategory, Collectors.counting()));
        return Map.of("averageGrade", avgGrade, "categoryDistribution", categoryDistribution);
    }

    public void generateDummyData() {
        if (!studentRepository.findAll().isEmpty()) return;

        Random random = new Random();
        for (int i = 0; i < 100; i++) {
            Student s = new Student();
            s.setGrades(IntStream.range(0, 5).map(x -> 60 + random.nextInt(40)).boxed().toList());
            s.setAttendance(60 + random.nextInt(40));
            s.setAssignments(60 + random.nextInt(40));
            s.setGroupScore(1 + random.nextInt(10));
            StudentUtils.enrichStudent(s);
            studentRepository.save(s);
        }
    }
}
